---
name: High-Efficiency Enterprise
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fd'
  surface-container: '#ededf8'
  surface-container-high: '#e7e7f2'
  surface-container-highest: '#e1e2ec'
  on-surface: '#191b23'
  on-surface-variant: '#434654'
  inverse-surface: '#2e3038'
  inverse-on-surface: '#f0f0fb'
  outline: '#737685'
  outline-variant: '#c3c6d6'
  surface-tint: '#0c56d0'
  primary: '#003d9b'
  on-primary: '#ffffff'
  primary-container: '#0052cc'
  on-primary-container: '#c4d2ff'
  inverse-primary: '#b2c5ff'
  secondary: '#006c47'
  on-secondary: '#ffffff'
  secondary-container: '#82f9be'
  on-secondary-container: '#00734c'
  tertiary: '#5e3c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#7d5200'
  on-tertiary-container: '#ffca81'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001848'
  on-primary-fixed-variant: '#0040a2'
  secondary-fixed: '#82f9be'
  secondary-fixed-dim: '#65dca4'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005235'
  tertiary-fixed: '#ffddb3'
  tertiary-fixed-dim: '#ffb950'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ec'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  column-gap: 16px
  container-padding: 24px
---

## Brand & Style

The design system is engineered for high-stakes administrative environments where clarity, speed, and precision are paramount. The brand personality is **authoritative, dependable, and systematically efficient**, designed to instill confidence in users managing high-value organizational assets.

The visual style follows a **Corporate Modern** approach with a focus on data density and functional clarity. It prioritizes information hierarchy over decorative elements, utilizing a structured layout that minimizes cognitive load during complex resource allocation tasks. The aesthetic is "utilitarian-premium"—clean, aligned, and professional, ensuring that the interface feels like a high-performance tool rather than a generic consumer app.

## Colors

The palette is rooted in industry-standard professional tones to ensure instant recognizability of system states. 

- **Primary (Corporate Blue):** Used for action-oriented elements, navigation, and primary branding. It represents stability and trust.
- **Success (Green):** Specifically reserved for "Available" or "Healthy" asset statuses and completed workflows.
- **Warning (Amber):** Highlighting "Maintenance" or "Low Stock" alerts that require attention but not immediate panic.
- **Error (Red):** Critical indicators for "Lost" assets, system failures, or "Retired" status.
- **Neutrals:** A sophisticated range of grays built on a deep navy base (`#091E42`) to maintain a professional "Enterprise" feel, used for text, borders, and subtle background layering.

## Typography

This design system utilizes **Inter** for its exceptional legibility at small sizes and high-density layouts. For technical data—such as Asset IDs, Serial Numbers, and SKU codes—**JetBrains Mono** is employed to provide clear character differentiation (e.g., distinguishing '0' from 'O').

- **Headlines:** Bold and tight for dashboard headers.
- **Body Text:** Primarily set at 14px (`body-md`) for the main interface to maximize information density without sacrificing readability. 13px (`body-sm`) is utilized for data tables.
- **Labels:** Uppercase styles are used sparingly for section headers to create clear vertical rhythm.

## Layout & Spacing

The system uses a **Fluid-Fixed Hybrid Grid**. Side navigation remains fixed at 240px, while the main content area utilizes a 12-column fluid grid.

- **Data Density:** A strict 4px baseline grid ensures alignment. In data-heavy views (tables/lists), vertical padding is reduced to `sm` (8px) to allow more rows to be visible above the fold.
- **Margins:** Standard page margins are 24px (`lg`).
- **Breakpoints:**
  - **Desktop (1440px+):** Full 12-column layout.
  - **Tablet (768px - 1439px):** Navigation collapses to icons, 8-column content grid.
  - **Mobile (Below 768px):** Single column, 16px horizontal margins.

## Elevation & Depth

To maintain a "clean and professional" look, this design system avoids heavy shadows. Instead, it uses **Tonal Layering** and **Low-Contrast Outlines**.

- **Level 0 (Background):** Soft gray (`#F4F5F7`) used for the main application canvas.
- **Level 1 (Cards/Surface):** Pure white background with a 1px border (`#DFE1E6`). No shadow.
- **Level 2 (Modals/Popovers):** Pure white with a subtle, tight shadow (0px 4px 8px rgba(9, 30, 66, 0.08)) and a 1px border.
- **Depth Hierarchy:** Information is organized through nesting and borders rather than elevation, ensuring the UI remains "flat" and efficient for rendering large datasets.

## Shapes

The design system uses **Soft (0.25rem)** corners to balance professional rigidity with modern UI sensibilities.

- **Small Components:** Checkboxes, input fields, and small buttons use `rounded` (4px).
- **Large Components:** KPI Cards and Modals use `rounded-lg` (8px).
- **Status Badges:** Use a higher roundedness (up to 16px) to distinguish them as distinct status pills within data tables.

## Components

### Data Tables
Tables are the core of this design system. 
- **Row Height:** 40px (Standard) or 32px (High-Density).
- **Header:** Sticky headers with a subtle gray background and 12px semi-bold labels.
- **Cell Content:** Left-aligned for text, right-aligned for currency/numbers, center-aligned for status badges.

### Status Badges (Pills)
Used for asset lifecycle tracking:
- **Available:** Green background (10% opacity) + Green text.
- **Allocated:** Blue background (10% opacity) + Blue text.
- **Reserved:** Gray background (10% opacity) + Gray text.
- **Maintenance:** Amber background (10% opacity) + Amber text.
- **Lost/Retired:** Red background (10% opacity) + Red text.

### KPI Cards
Display high-level metrics (e.g., "Total Asset Value"). Features a 14px label, 24px bold value, and a small sparkline or percentage indicator for trend data.

### Input Fields
Standardized height of 36px. Borders are 1px gray, turning Blue (Primary) on focus. Labels are positioned above the field, never as placeholders only.

### Specialized Forms
Two-column layouts for asset registration. Includes "Searchable Select" components for manufacturer and category selection to handle large taxonomies.